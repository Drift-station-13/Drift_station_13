package dspal

import java.net.URL
import java.io.File
import java.util.Scanner
import java.util.Calendar

import javax.swing.*

var log_text = "";
var rep_path = "../../../Drift_station_13";

fun set_rep_path(path: String){
    rep_path = File(path).getCanonicalPath();
}

fun is_rep_path_ok(): Boolean{
    val file_p = File(rep_path);
    if(file_p.exists()){
        if(file_p.isDirectory()){
            if(File(rep_path + "/yori_station.dme").exists()){
                return true;
            }
        }else{
            error("Path is not a directory.");
            error("given path: " + file_p + ", canonical path: " + file_p.canonicalFile);
        }
    }else{
        error("Path is not valid.");
        error("given path: " + file_p);
    }
    return false;
}

fun process_url(url: String): String{
    log_text = "\n";
    if(!is_rep_path_ok()){
        return log_text;
    }

    var url_split = url.split('/');

    if(url_split.count() > 6){
        if(url_split[2] == "github.com" && url_split[5] == "pull") {
            val patch_path = url_split[6] + ".patch";
            var diff: String;
            if (!File(patch_path).exists()) {
                diff =
                    URL("https://patch-diff.githubusercontent.com/raw/" + url_split[3] + '/' + url_split[4] + "/pull/" + url_split[6] + ".patch").readText();
                File(patch_path).writeText(diff);
            }

            apply_patch(File(patch_path).getCanonicalPath(), rep_path);

            //log it
            val calendar = Calendar.getInstance()
            File(rep_path + "/DS-Pal-auto-pull.txt").appendText(
                "\nhttps://github.com/" + url_split[3] + '/' + url_split[4] + "/pull/" + url_split[6] + ".patch - [" + calendar.get(
                    Calendar.MONTH
                ) + "/" + calendar.get(Calendar.DAY_OF_MONTH) + "/" + calendar.get(Calendar.YEAR) + "]"
            );
        }else{
            error("not a github pull reqest link. (not match template)");
        }
    }else{
        error("not a github pull reqest link. (less then 6 pram)");
    }

    return log_text;
}

fun apply_patch(patch_path: String, rep_path: String){
    val git_apply_flags = "--ignore-space-change --ignore-whitespace --inaccurate-eof";
    var sucess = true;
    var err_msg = "";
    //log("[ds-pal] git command: " + "git apply --check "+git_apply_flags+" "+patch_path);
    var proc = Runtime.getRuntime().exec("git apply --check "+git_apply_flags+" "+patch_path, null, File(rep_path));
    Scanner(proc.errorStream).use {
        while (it.hasNextLine()){
            val line = it.nextLine()
            log("[cmd]: " + line)
            if(line.contains("error") && sucess){
                sucess = false;
                err_msg = "Patch will not apply due to diffrences in the codebase.";
            }else if(line.contains("unknown option") && sucess){
                sucess = false;
                err_msg = "Internal error generating git command.";
            }
        }
    }
    if(sucess){
        Runtime.getRuntime().exec("git apply "+git_apply_flags+" "+patch_path, null, File(rep_path));
        log("\n -=-=- Applyed patch ! =-=-=-");
        //File(patch_path).delete();
    }else{
        error(err_msg);
    }
}

fun log(msg: String){
    println(msg);
    log_text = log_text + '\n' + msg;
}

fun error(msg: String){
    log("[ds-pal]: error: " + msg);
}
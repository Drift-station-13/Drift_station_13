package dspal

import java.net.URL
import java.io.File
import java.util.Scanner
import java.util.Calendar

import javax.swing.*

var log_text = "";
var rep_path = "../../../Drift_station_13";
val DME_FILE_NAME = "yori_station.dme";
var ignore_dmi_files = true;
var only_dm_files = false;

fun set_rep_path(path: String){
    rep_path = File(path).getCanonicalPath();
}

fun set_only_dm_files(v: Boolean){
    only_dm_files = v;
}

fun set_ignore_dmi_files(v: Boolean){
    ignore_dmi_files = v;
}

fun is_rep_path_ok(): Boolean{
    val file_p = File(rep_path);
    if(file_p.exists()){
        if(file_p.isDirectory()){
            if(File(rep_path + '/' + DME_FILE_NAME).exists() && File(rep_path + "/yori_station.dme").isFile){
                return true;
            }else{
                error("This is not the Drift Station repo!");
            }
        }else{
            error("Path is not a directory.");
            error("given path: " + file_p + ", canonical path: " + file_p.canonicalFile);
        }
    }else{
        error("Path is not valid.");
        error("given path: " + file_p);
    }
    return false;
}

fun process_url(url: String): String{
    log_text = "\n";
    if(!is_rep_path_ok()){
        return log_text;
    }

    var url_split = url.split('/');

    if(url_split.count() > 6){
        if(url_split[2] == "github.com" && url_split[5] == "pull") {
            val patch_path = url_split[6] + ".patch";
            var diff: String;
            if (!File(patch_path).exists()) {
                diff =
                    URL("https://patch-diff.githubusercontent.com/raw/" + url_split[3] + '/' + url_split[4] + "/pull/" + url_split[6] + ".patch").readText();
                File(patch_path).writeText(diff);
            }

            if(apply_patch(File(patch_path).getCanonicalPath(), rep_path)){
                //log it
                val calendar = Calendar.getInstance()
                File(rep_path + "/DS-Pal-auto-pull.txt").appendText("\nhttps://github.com/" + url_split[3] + '/' + url_split[4] + "/pull/" + url_split[6] + ".patch - [" + calendar.get(Calendar.MONTH) + "/" + calendar.get(Calendar.DAY_OF_MONTH) + "/" + calendar.get(Calendar.YEAR) + "]");
            }
        }else{
            error("not a github pull reqest link. (not match template)");
        }
    }else{
        error("not a github pull reqest link. (less then 6 pram)");
    }

    return log_text;
}

fun apply_dme_patch(patch_path: String, rep_path: String){
    //check if dme patch is needed.
    val dme_regex_match = "\\w*\\.dme".toRegex();
    if(!File(patch_path).readText().contains(dme_regex_match)){
        return;
    }
    //its needed.
    log("--- attempting to auto patch " + DME_FILE_NAME + " ---");
    var dme_file = File(patch_path).readText();
    File(patch_path + ".mp").writeText(dme_file.replace(dme_regex_match, DME_FILE_NAME));
    //check if git will let this happen.
    val git_apply_flags = "--inaccurate-eof --unidiff-zero -C0 --include="+DME_FILE_NAME+" --exclude=**.*";
    var sucess = true;
    var proc = Runtime.getRuntime().exec("git apply --check "+git_apply_flags+" "+patch_path + ".mp", null, File(rep_path));
    Scanner(proc.errorStream).use {
        while (it.hasNextLine()){
            val line = it.nextLine()
            log("[cmd]: " + line)
            if(line.contains("error") && sucess){
                sucess = false;
            }else if(line.contains("unknown option") && sucess){
                sucess = false;
            }
        }
    }
    if(sucess){
        //backup dme
        File(rep_path+'/'+DME_FILE_NAME+".old").writeText(File(rep_path+'/'+DME_FILE_NAME).readText());
        log("backed up "+DME_FILE_NAME+" as "+DME_FILE_NAME+".old");

        Runtime.getRuntime().exec("git apply "+git_apply_flags+" "+patch_path + ".mp", null, File(rep_path));
        log("\n -=-=- "+DME_FILE_NAME+" patched ! =-=-=-");
    }else{
        error(".dme changes will not be applied, you will need to manualy checkoff new files and remove old ones from: " + DME_FILE_NAME);
    }

}

fun apply_patch(patch_path: String, rep_path: String): Boolean{
    var git_apply_flags = "--inaccurate-eof --exclude=**.dme ";
    if(only_dm_files){
        git_apply_flags = git_apply_flags + "--include=**.dm --exclude=**.*";
    }else if(ignore_dmi_files){
        git_apply_flags = git_apply_flags + "--exclude=**.dmi";
    }
    var sucess = true;
    var err_msg = "";
    //log("[ds-pal] git command: " + "git apply --check "+git_apply_flags+" "+patch_path);
    var proc = Runtime.getRuntime().exec("git apply --check "+git_apply_flags+" "+patch_path, null, File(rep_path));
    Scanner(proc.errorStream).use {
        while (it.hasNextLine()){
            val line = it.nextLine()
            log("[cmd]: " + line)
            if(line.contains("error") && sucess){
                sucess = false;
                err_msg = "Patch will not apply due to diffrences in the codebase.";
            }else if(line.contains("unknown option") && sucess){
                sucess = false;
                err_msg = "Internal error generating git command.";
            }
        }
    }
    if(sucess){
        Runtime.getRuntime().exec("git apply "+git_apply_flags+" "+patch_path, null, File(rep_path));
        log("\n -=-=- Applyed patch ! =-=-=-");
        apply_dme_patch(patch_path, rep_path);
    }else{
        error(err_msg);
    }
    return sucess;
}

fun log(msg: String){
    println(msg);
    log_text = log_text + '\n' + msg;
}

fun error(msg: String){
    log("[ds-pal]: error: " + msg);
}
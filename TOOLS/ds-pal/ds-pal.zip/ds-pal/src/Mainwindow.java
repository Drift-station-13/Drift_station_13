import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JCheckBox;
import javax.swing.event.ChangeListener;

import javax.swing.event.ChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import static dspal.DspalKt.*;

public class Mainwindow {

    private JFrame frmDsPal;
    private JTextField patch_pull_txt;
    private JTextArea log;
    private JTextField repo_path_txt;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Mainwindow w = new Mainwindow();
                    w.frmDsPal.setVisible(true);
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public Mainwindow() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frmDsPal = new JFrame();
        frmDsPal.setResizable(false);
        frmDsPal.setTitle("DS Pal");
        frmDsPal.setBounds(100, 100, 610, 510);
        frmDsPal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmDsPal.getContentPane().setLayout(null);

        patch_pull_txt = new JTextField();
        patch_pull_txt.setBounds(114, 11, 387, 20);
        frmDsPal.getContentPane().add(patch_pull_txt);
        patch_pull_txt.setColumns(10);

        JLabel lblNewLabel = new JLabel("Patch pull req:");
        lblNewLabel.setBounds(10, 14, 84, 14);
        frmDsPal.getContentPane().add(lblNewLabel);

        JButton patch_pull_btn = new JButton("Patch");
        patch_pull_btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                //appendLogText(.process_url(patch_pull_txt.getText()));
                log.append((process_url(patch_pull_txt.getText())));
            }
        });
        patch_pull_btn.setBounds(511, 10, 73, 23);
        frmDsPal.getContentPane().add(patch_pull_btn);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 61, 574, 399);
        frmDsPal.getContentPane().add(scrollPane);

        log = new JTextArea();
        log.setRows(25);
        scrollPane.setColumnHeaderView(log);
        log.setEditable(false);
        log.setWrapStyleWord(true);
        log.setLineWrap(true);

        repo_path_txt = new JTextField();
        repo_path_txt.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent arg0) {
                set_rep_path(repo_path_txt.getText());
            }
        });
        repo_path_txt.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent arg0) {
                set_rep_path(repo_path_txt.getText());
            }
        });
        repo_path_txt.setEditable(false);
        repo_path_txt.setText("../../../Drift_station_13");
        repo_path_txt.setBounds(124, 36, 460, 20);
        frmDsPal.getContentPane().add(repo_path_txt);
        repo_path_txt.setColumns(10);

        JCheckBox is_in_tools_chkbox = new JCheckBox("In tools folder");
        is_in_tools_chkbox.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent arg0) {
                if(!is_in_tools_chkbox.isSelected()) {
                    repo_path_txt.setEditable(true);
                    repo_path_txt.setText("./Drift_station_13");
                }else {
                    repo_path_txt.setEditable(false);
                    repo_path_txt.setText("../../../Drift_station_13");
                }
                set_rep_path(repo_path_txt.getText());
            }
        });
        is_in_tools_chkbox.setSelected(true);
        is_in_tools_chkbox.setBounds(10, 35, 106, 23);
        frmDsPal.getContentPane().add(is_in_tools_chkbox);
    }
}
